# sitio-jorge

Sitio personal de **Jorge el Manzana**.

## Cómo publicar rápido

1. Inicia sesión en GitHub y abre este repositorio.
2. Sube los archivos `index.html` (y los que quieras) con **Add file → Upload files**.
3. Activa **GitHub Pages** (Settings → Pages → Deploy from a branch → `main` o `master`, carpeta `/root`).
4. O bien, conecta el repo a **Vercel** y despliega con un click.
